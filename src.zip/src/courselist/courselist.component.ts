import { CourseService } from '../course_service/course.service';
import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import {CourseListInterface} from './courselist.interface';
@Component({
    templateUrl:"./courselist.component.html",
})

export class CourseListComponent implements OnInit{
   imgWidth:number=200;
  imgHeight:number=100;
  
  title='Course Lists'
  courselist = [];

     constructor( private location: Location,private course:CourseService ) { 
  }

ngOnInit(): void {
  this.courselist=this.course.getCourse();
}

 goBack() {
    this.location.back();
  }

 

onRatingClicked(rate:string):void{
  this.title=rate;
}
}