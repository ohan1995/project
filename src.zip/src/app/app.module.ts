import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {FrontComponent} from '../front/front.component';
import {CourseComponent} from '../courses/course.component';

import {FooterComponent} from '../footer/footer.component';
import{CourseListComponent} from '../courselist/courselist.component';
import {AboutComponent} from '../about/about.component';
import {ErrorComponent} from '../error/error.component';
import {FormsModule} from '@angular/forms';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import {CourseDetailComponent} from '../coursedetail/coursedetail.component';
import {CourseRatingComponent} from '../courserating/courserating.component';
@NgModule({
  declarations: [
    AppComponent,FrontComponent,CourseComponent,
    FooterComponent,CourseListComponent,
    AboutComponent,ErrorComponent,
    CourseDetailComponent,
    CourseRatingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    Ng2SearchPipeModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
