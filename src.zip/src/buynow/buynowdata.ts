export class BuyNowData{
    public name='';
    public email='';
    public netbanking='';
    public creditcard='';
    public debitcard='';
     public selectbank='';
     public cardNumber='';
     public cardName='';
     public cvv='';
     public expirydate='';
}