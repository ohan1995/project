import { Component } from '@angular/core';

@Component({
  selector: 'front',
  templateUrl: './front.component.html',
  styleUrls:['./front.component.css']
})
export class FrontComponent {
  title = 'Code-Course';
}
  