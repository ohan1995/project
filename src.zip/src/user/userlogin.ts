export class UserLoginData{
    public username='';
    public password='';
    public newsletter='';
    public email='';
    public phone='';
}