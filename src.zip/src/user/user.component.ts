import { NgForm } from '@angular/forms';
import { User } from './user';
import { Component, OnInit } from '@angular/core';

@Component({
templateUrl:'./user.component.html'
})


export class UserComponent{
    
    user = new User()
    constructor(){

    }

    save(userForm:NgForm){
        console.log(userForm.form);
      }
    
}