import {Component,OnInit} from '@angular/core';
import {FormControl,FormGroup,FormBuilder} from '@angular/forms'

@Component({
    selector:'loginform',
    templateUrl:'./userlogin.component.html'
})
export class UserLoginComponent implements OnInit{
    loginForm:FormGroup;

constructor(private fb:FormBuilder){

    }
    login= this.fb.group({
        username:'',
        password:''
    })

    

    ngOnInit(): void {
            
    }
    
}