export class ContactUsData{
    public email='';
    public message='';
    
}