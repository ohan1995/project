package com.gaurav.springbatchdatabasetocsv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBatchDatabaseToCsvApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBatchDatabaseToCsvApplication.class, args);
	}

}
