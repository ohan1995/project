package com.gaurav.springbatchdatabasetocsv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBatchDatabaseToCsvApplicationTests {

	@Test
	void contextLoads() {
	}

}
