export class User{
    username:string;
    userid:string;
    password:string
}