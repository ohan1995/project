import { Router } from '@angular/router';
import { DataService } from '../dataservice/data.service';
import { User } from './user.model';
import { Component, OnInit } from '@angular/core';
import{NgForm} from '@angular/forms'

@Component({
    selector:'user',
    templateUrl:'./user.component.html',
    styleUrls:['./user.component.css']
})

export class UserComponent implements OnInit{
user=new User()
username:string

    constructor(private service:DataService, private router:Router){}

    ngOnInit(): void {
        this.service.name.subscribe(data=>this.username=data)
    }
    userRegister(form:NgForm){
        console.log(form.value)
        console.log(form.value.username)
        this.username=form.value.username
        this.service.getUsername(form.value.username)
        this.router.navigate(['/quiz'])
    }

}