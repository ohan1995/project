import { DataService } from '../dataservice/data.service';
import { QuizComponent } from '../quiz/quiz.component';
import { Component, Input } from '@angular/core';

@Component({
    selector:'result',
    templateUrl:'./result.component.html'
})

export class ResultComponent{
question:any
answer:any
    constructor(private dataService:DataService){}

    ngOnInit(): void {
        this.dataService.quesion.subscribe(question=>this.question=question)
        this.dataService.answer.subscribe(answer=>this.answer=answer)
    }
   
}