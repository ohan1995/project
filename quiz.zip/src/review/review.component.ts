import { QuizService } from '../quiz/quiz.service';
import { DataService } from '../dataservice/data.service';
import { QuizComponent } from '../quiz/quiz.component';
import { Component, Input } from '@angular/core';

@Component({
    selector:'review',
    templateUrl:'./review.component.html'
})

export class ReviewComponent{
question:any
answer:any
selected:any[]
quiz:any[]
selectedAnswers:any[]
correctAnswers:any
right_Answer:string
wrong_Answer:string

    constructor(private dataService:DataService,private service:QuizService){}

    ngOnInit(): void {
        this.service.getQuestions().subscribe(
            data=>{this.quiz=data
                    this.correctAnswers=Object.keys(this.quiz).map(x=>this.quiz[x].answer)   
                       console.log(this.correctAnswers)    
			}
			
        )
        this.dataService.quesion.subscribe(question=>this.question=question)
        this.dataService.answer.subscribe(answer=>this.answer=answer)
        this.dataService.seletedAnswer.subscribe(
            selected=>{this.selected=selected})
            
            this.selectedAnswers=Object.keys(this.selected).map(x=>this.selected[x])
            console.log(this.selectedAnswers)

            for(let i=0;i<this.correctAnswers.length;i++){
                if(this.selectedAnswers==this.correctAnswers){
                    this.right_Answer='Right Answer'
                }else{
                    this.wrong_Answer='Wrong Answer'
                }
            }
    }
}