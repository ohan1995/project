import { ModalDirective } from 'ngx-bootstrap/modal/ngx-bootstrap-modal';
import { Router } from '@angular/router';
import { DataService } from '../dataservice/data.service';
import { NgForm } from '@angular/forms';
import { Quiz } from './quiz.model';
import { QuizService } from './quiz.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { CountdownComponent } from 'ngx-countdown';


@Component({
    templateUrl:'./quiz.component.html'
})

export class QuizComponent implements OnInit{
username
quiz:any
totalAnswered:number=0;
rightAnswer:number=0
questions:any
selected:any[]
question:any
answer:any
correctAnswers:any[]
model='quiz'
selectAnswers:any

  @ViewChild('countdown', {static:false}) counter: CountdownComponent;
  @ViewChild('submitModal',{static:false})submitModal:ModalDirective

   constructor(private service:QuizService, private dataService:DataService, private router:Router){}
    ngOnInit(): void {
        this.service.getQuestions().subscribe(
            data=>{this.quiz=data	
				this.model='quiz'
		
			})
			this.dataService.name.subscribe(data=>this.username=data)
			console.log(this.username)
    };

submitTest(form:NgForm) {
		this.rightAnswer = 0;
		this.totalAnswered = 0;
		this.selected=form.value

		this.correctAnswers=form.value
		
		this.service.getQuestions().subscribe(
			data=>{
				this.questions=data
				for(let i=0,j=1;i<this.questions.length;i++,j++){
					console.log("answers : "+this.questions[i].answer)
					
					console.log("selected : "+this.selected[j])

						
					if(this.selected[j] in this.questions[i] && (this.selected[j] !=null)){
					
						this.totalAnswered++
					
						if(this.selected[j] ==this.questions[i]["answer"]){
					
						this.rightAnswer++
						}
					}
				}
				this.dataService.changeNumbers(this.totalAnswered,this.rightAnswer)
				this.dataService.getSelectedAnswers(this.selected)
				this.submitModal.show();
		});
		
	}
	cancel(){
		this.model='cancel'		
	}
}