import { ModalDirective } from 'ngx-bootstrap/modal/ngx-bootstrap-modal';
import { Router } from '@angular/router';
import { DataService } from '../dataservice/data.service';
import { NgForm } from '@angular/forms';
import { Quiz } from './quiz.model';
import { QuizService } from './quiz.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { CountdownComponent } from 'ngx-countdown';


@Component({
    templateUrl:'./quiz.component.html'
})

export class QuizComponent implements OnInit{

quiz:any
totalAnswered:number=0;
rightAnswer:number=0;
totalQuestionAttempt:number
totalCorrectAnswers:number
questions:any
selected:any[]
question:any
answer:any
correctAnswers:any[]
model='quiz'
selectAnswers:any
k:number=0
  @ViewChild('countdown', {static:false}) counter: CountdownComponent;
  @ViewChild('submitModal',{static:false})submitModal:ModalDirective

   constructor(private service:QuizService, private dataService:DataService, private router:Router){}
    ngOnInit(): void {
        this.service.getQuestions().subscribe(
            data=>{this.quiz=data	
				this.model='quiz'
			}
			
        )
		this.dataService.quesion.subscribe(question=>this.question=question)
		this.dataService.answer.subscribe(answer=>this.answer=answer)
		this.dataService.seletedAnswer.subscribe(selected=>this.selectAnswers=selected)
		
    };

submitTest(form:NgForm) {
		this.rightAnswer = 0;
		this.totalAnswered = 0;
		this.selected=form.value

		this.correctAnswers=form.value
		
		this.service.getQuestions().subscribe(
			data=>{
				this.questions=data
				for(let i=0,j=1;i<this.questions.length;i++,j++){
					console.log("answers : "+this.questions[i].answer)
					
					console.log("selected : "+this.selected[j])

						
					if(this.selected[j] in this.questions[i] && (this.selected[j] !=null)){
					
						this.totalAnswered++
					
						if(this.selected[j] ==this.questions[i]["answer"]){
					
						this.rightAnswer++
						}
					}
				}
				console.log("total questions attempt : "+this.totalAnswered)
				console.log("total correct answers : "+this.rightAnswer)
				this.totalQuestionAttempt=this.totalAnswered
				this.totalCorrectAnswers=this.rightAnswer
				this.dataService.changeNumbers(this.totalQuestionAttempt,this.totalCorrectAnswers)
				this.dataService.getSelectedAnswers(this.selected)
				this.submitModal.show();
				//this.router.navigate(['/result'])
		});
		
	}
	view(){
		this.model='review'
		console.log("totalQuestionAttempt : "+this.totalQuestionAttempt)
		console.log("totalCorrectAnswers : "+this.totalCorrectAnswers)		
	}
}