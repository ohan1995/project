import { Quiz } from './quiz.model';
import { Observable } from 'rxjs/internal/Rx';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn:'root'
})

export class QuizService{
 url="./data/questions.json"
 
    constructor(private httpservice:HttpClient){}

   

    getQuestions(){
        return this.httpservice.get(this.url)
    }
}