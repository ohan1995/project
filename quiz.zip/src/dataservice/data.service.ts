import { BehaviorSubject } from 'rxjs';
import { Injectable } from '@angular/core';


@Injectable({
    providedIn:'root'
})

export class DataService{
    private totalQuestion=new BehaviorSubject(''+0);
    private totalAnswer=new BehaviorSubject(''+0)
    private selected=new BehaviorSubject([])
   private username=new BehaviorSubject('')

        quesion = this.totalQuestion.asObservable();
        answer = this.totalAnswer.asObservable();
        seletedAnswer=this.selected.asObservable();
        name=this.username.asObservable();

    changeNumbers(question,answer){
        this.totalQuestion.next(question);
        this.totalAnswer.next(answer)
    }
    
    get data(){
      return  this.selected.getValue();
    }

    set data(selected){
        this.selected.next(selected)
    }
    
    getSelectedAnswers(selected){
        this.selected.next(selected)
    }

    getUsername(name){
        this.username.next(name)
    }
    


}