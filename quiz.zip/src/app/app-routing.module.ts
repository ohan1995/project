import { UserComponent } from '../user/user.component';
import { ResultComponent } from '../result/result.component';
import { ReviewComponent } from '../review/review.component';
import { QuizComponent } from '../quiz/quiz.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  {path:'quiz',component:QuizComponent},
  {path:'view',component:ReviewComponent},
  {path:'result',component:ResultComponent},
  {path:'user',component:UserComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
